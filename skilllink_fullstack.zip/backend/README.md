# SkillLink — Backend (Express)
- cd backend
- npm install
- COPY .env.example to .env and set MONGODB_URI etc
- npm start
