const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Simple in-memory sample dataset (replace with MongoDB collection in production)
const sampleJobs = [
  { id:1, title:'Tailor Apprentice', provider:'Local Tailor — Village A', skills:['tailoring','sewing'], location:'Village A', distance_km:2, type:'Apprenticeship', description:'On-the-job tailoring apprenticeship.'},
  { id:2, title:'Agriculture Field Worker', provider:'Agri Co-op — Block B', skills:['farm labor','harvesting'], location:'Block B', distance_km:10, type:'Job', description:'Seasonal farm work.'},
  { id:3, title:'Electrician Trainee', provider:'MSME Electric — Town C', skills:['wiring','basic-electrical'], location:'Town C', distance_km:15, type:'Training', description:'Short course with stipend.'}
];

// POST /api/match -> { skill, location, lang } returns fuzzy matches
app.post('/api/match', (req, res) => {
  const { skill, location } = req.body || {};
  if(!skill) return res.status(400).json({ error:'skill required' });

  const q = skill.toLowerCase();
  // naive matching: check if any job's skills include q or contain q as substring
  const matches = sampleJobs.filter(j => 
    j.skills.some(s => s.toLowerCase().includes(q) || q.includes(s.toLowerCase()))
  ).map(j => ({ ...j }));

  // if none, return top 3 nearest (simulated)
  if(matches.length===0){
    return res.json({ matches: sampleJobs.slice(0,3) });
  }
  res.json({ matches });
});

// Health
app.get('/api/health', (req,res)=>res.json({status:'ok',timestamp:Date.now()}));

const port = process.env.PORT || 5000;
app.listen(port, ()=> console.log('SkillLink backend running on',port));
