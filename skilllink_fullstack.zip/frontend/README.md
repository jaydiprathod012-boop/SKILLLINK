# SkillLink — Frontend
Simple React frontend for SkillLink demo.

Installation:
- cd frontend
- npm install
- npm start

The frontend expects backend API at same host under /api.
