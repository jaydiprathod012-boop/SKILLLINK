import React, {useState} from 'react';
import axios from 'axios';
import i18n from './i18n';

function App(){
  const [skill, setSkill] = useState('');
  const [location, setLocation] = useState('');
  const [results, setResults] = useState([]);
  const [lang, setLang] = useState('en');

  const submit = async (e) => {
    e && e.preventDefault();
    try{
      const res = await axios.post('/api/match', { skill, location, lang });
      setResults(res.data.matches || []);
    }catch(err){
      alert('Error contacting server. See console.');
      console.error(err);
    }
  };

  return (
    <div className="app">
      <h1>SkillLink</h1>
      <p><em>AI-Powered Skill-to-Job Matching for Rural India</em></p>

      <section style={{background:'#f7f7f7',padding:16,borderRadius:8}}>
        <h2>Quick match</h2>
        <form onSubmit={submit}>
          <div>
            <label>Skill (type or speak):</label><br/>
            <input value={skill} onChange={e=>setSkill(e.target.value)} placeholder="e.g. tailoring, welding" style={{width:'100%'}}/>
          </div>
          <div style={{marginTop:8}}>
            <label>Location (village / district):</label><br/>
            <input value={location} onChange={e=>setLocation(e.target.value)} style={{width:'100%'}}/>
          </div>
          <div style={{marginTop:8}}>
            <label>Language:</label>
            <select value={lang} onChange={e=>setLang(e.target.value)}>
              <option value="en">English</option>
              <option value="hi">Hindi</option>
              <option value="bn">Bengali</option>
              <option value="ta">Tamil</option>
              <option value="te">Telugu</option>
            </select>
          </div>
          <div style={{marginTop:12}}>
            <button type="submit">Find matches</button>
          </div>
        </form>
      </section>

      <section style={{marginTop:20}}>
        <h3>Matches</h3>
        {results.length===0 && <p>No matches yet.</p>}
        <ul>
          {results.map((m,idx)=>(
            <li key={idx} style={{marginBottom:8}}>
              <strong>{m.title}</strong><br/>
              {m.provider} — {m.distance_km} km — <em>{m.type}</em><br/>
              <small>{m.description}</small>
            </li>
          ))}
        </ul>
      </section>

      <footer style={{marginTop:30,fontSize:13,color:'#555'}}>
        <p>Vision: To make every Indian youth employable — <strong>“Every Skill Deserves an Opportunity.”</strong></p>
      </footer>
    </div>
  );
}

export default App;
